# -*- coding: utf-8 -*-
"""
Created on Wed Jul 29 22:21:08 2026

@author: VICTUS
"""
# ============================================
# Project Name : Study Tracker System
# Course       : Python Programming
# Description  : A console-based application
#                that helps students organize
#                and track their daily study plan.
# Developed By : Noor Alwedyan
# ============================================

subjects={}
def add_sub(subjects):
    while(True):
        
        ans=input("Do you want to add  subjects? (yes/no) ?! ")
        if ans=="yes":
            s=input("What subject did you study?")
            h=float(input("Add your target hours ?"))
            subjects[s]={"hours":h ,
                         "real hours":0,
                         "status":"not completed"}
        else:
             break
           
       
    print(subjects)
def total_sub(subjects):
    total=0
    for key in subjects.items():
        total+=1
    print("Total subjects =",total)
        

def view_study_plan(subjects):
    print("------Today's Study Plan------")
    print("\n")
    for key , value in subjects.items():
        print(f"subject: {key} ")
        print("Target hours:",value["hours"])
        print("Real hours:",value["real hours"])
        print("Status:",value["status"])
        print("\n")

def real_hours(subjects):
    print("To stop put (done) ")
    while(True):
        sub=(input("Which subject did you study? "))
        if sub=="done":
            break
        if sub in subjects:
            r_hour=float(input(f"Enter real hours for {sub} : "))
            subjects[sub]["real hours"]=r_hour
            subjects[sub]["status"]="completed"
        
        else:
             print("subject not in your plan !!!")
        
def total_hours(subjects):
    total=0
    for key,value in subjects.items():
        if value["status"]=="completed":
            total+=subjects[key]["real hours"]
    print("Total Real Hours = ",total ,"hours")
    
    if total==0:
        print("You haven't completed any study sessions yet. Let's start studying!")
    
'''
0 - 4      Beginner

5 - 9      Intermediate

10 - 19    Advanced

'''

def level(subjects):
    total=0
    for key,value in subjects.items():
        if value["status"]=="completed":
            total+=subjects[key]["real hours"]
    
    if 0<=total and total <=4:
        print("Level : Beginner")
    elif 5<=total and total <=9:
        print("Level : Intermediate")
    elif 10<=total and total <=19:
        print("Level : Advanced")
     
def count_completed(subjects):
    count=0
    for key,value in subjects.items():
        if value["status"]=="completed":
            count+=1
    print("Completed Subjects:",count)
def count_uncompleted(subjects):
    count=0
    for key,value in subjects.items():
        if value["status"]=="not completed":
            count+=1
    print("Remaining Subjects:",count)
           
def report_study(subjects):
    total_sub(subjects)
    count_completed(subjects)
    count_uncompleted(subjects)
    total_hours(subjects)
    level(subjects)
        
        
        
        
        
    
    
    
def welcoming(subjects):
    name=input("Enter your name :").title()
    print(f"------ Hello {name} ,Welcome to Our Study Tracker------")
    while(True):
        
        print(""" 
              1. Add study session
              2. View today's study
              3. Enter real hours study
              4. View total study hours
              5. Check my level
              6. How many subjects are completed?
              7.How many subjects are uncompleted?
              8. press to watch total subjects?
              9.press to show your report study ?
              10. Exit
                      """)
                
        
        serv=(input("Enter your service :"). title())
        if serv=="1":
                add_sub(subjects)
        if serv=="2":
            view_study_plan(subjects)
        if serv=="3":
            real_hours(subjects)
        if serv=="4":
            total_hours(subjects)
        if serv =="5":
            level(subjects)
        if serv=="6":
            count_completed(subjects)
        if serv=="7":
            count_uncompleted(subjects)
        if serv=="8":
            total_sub(subjects)
        if serv=="9":
            report_study(subjects)
        if serv=="10"  :
            break

            
        
        

          
          
          
          
          
          
          
                   


welcoming(subjects)

         